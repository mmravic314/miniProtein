master --query cd22_argTrp.pds --targetList ~/aqMasterDB/v2_162901_bc_30-scPDB/list.txt --bbRMSD --rmsdCut 0.17 --matchOut cd22_argTrp.m --seqOut cd22_argTrp.s --structOut matches/
